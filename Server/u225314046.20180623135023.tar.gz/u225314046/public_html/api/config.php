<?php
$servername = "mysql.hostinger.com";
$database = "u225314046_air";
$username = "u225314046_air";
$password = "Air451995";
?>
